import { _decorator, Component, EventTouch, ImageAsset, instantiate, Node, ParticleSystem2D, Prefab, Sprite, SpriteFrame, UITransform, Vec3 } from 'cc';
import { l } from './l';
const { ccclass, property } = _decorator;

@ccclass('zha')
export class zha extends Component {
    @property(Prefab)
    particlePrefab: Prefab = null!;  // 粒子预制体
    
    @property

    particleOffset: Vec3 = new Vec3(0, 0, 0);  // 粒子位置偏移
    
    @property
    autoDestroy: boolean = true;  // 是否自动销毁粒子
    
    @property
    destroyDelay: number = 2.0;   // 粒子自动销毁延迟时间
    
    @property

    respawnDelay: number = 1.5;   // Sprite重新显示延迟时间
    
    @property
    disableTouchDuringEffect: boolean = true;  // 效果期间禁用点击
    
    private isAnimating: boolean = false;  // 是否正在播放动画
    private originalScale: Vec3 = new Vec3(1, 1, 1);  // 保存原始缩放
    @property(ImageAsset)
    particleColorSource: ImageAsset = null!;  // 新增：粒子颜色源图片
    
    start() {
        // 保存原始缩放
        this.originalScale = this.node.scale.clone();
        
        // 添加触摸事件
        this.node.on(Node.EventType.TOUCH_START, this.onTouchStart, this);
        this.node.on(Node.EventType.TOUCH_END, this.onTouchEnd, this);
        this.node.on(Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this);
    }
    
    onDestroy() {
        // 移除事件监听
        this.node.off(Node.EventType.TOUCH_START, this.onTouchStart, this);
        this.node.off(Node.EventType.TOUCH_END, this.onTouchEnd, this);
        this.node.off(Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this);
    }
    
    onTouchStart(event: EventTouch) {
        if (this.isAnimating && this.disableTouchDuringEffect) return;
        
        // 触摸开始，添加按下效果
        this.node.scale = new Vec3(0.95, 0.95, 1);
    }
    
    onTouchEnd(event: EventTouch) {
        if (this.isAnimating && this.disableTouchDuringEffect) return;
        
        // 恢复缩放
        this.node.scale = this.originalScale.clone();
        
        // 获取触摸位置（世界坐标）
        const touchPos = event.getUILocation();
        
        // 将世界坐标转换为节点本地坐标
        const uiTransform = this.getComponent(UITransform);
        if (!uiTransform) return;
        
        const localPos = uiTransform.convertToNodeSpaceAR(new Vec3(touchPos.x, touchPos.y, 0));
        
        // 开始爆炸效果
        this.startExplosionEffect(localPos);
    }
    
    onTouchCancel(event: EventTouch) {
        // 触摸取消，恢复缩放
        this.node.scale = this.originalScale.clone();
    }
    
    /**
     * 开始爆炸效果
     */
    startExplosionEffect(position: Vec3) {
        if (this.isAnimating) return;
        
        this.isAnimating = true;
        
        // 1. Sprite消失（可以添加消失动画）
        this.hideSprite();
        
        // 2. 生成粒子效果
        this.spawnParticle(position);
        
        // 3. 延迟后重新显示Sprite
        this.scheduleOnce(() => {
            this.showSprite();
            this.isAnimating = false;
        }, this.respawnDelay);
    }
    
    /**
     * 隐藏Sprite（带动画效果）
     */
    hideSprite() {
        // 方法1：直接隐藏
        this.node.active = false;
        
        // 方法2：淡出效果（如果有Sprite组件）
        // const sprite = this.getComponent(Sprite);
        // if (sprite) {
        //     sprite.color = sprite.color.clone();
        //     sprite.color.a = 0;
        // }
        
        // 方法3：缩放消失动画
        // this.node.scale = new Vec3(0, 0, 1);
        // 或者使用tween动画
    }
    
    /**
     * 显示Sprite（带动画效果）
     */
    showSprite() {
        // 方法1：直接显示
        this.node.active = true;
        
        // 方法2：淡入效果
        // const sprite = this.getComponent(Sprite);
        // if (sprite) {
        //     sprite.color = sprite.color.clone();
        //     sprite.color.a = 255;
        // }
        
        // 方法3：缩放出现动画
        this.node.scale = new Vec3(0, 0, 1);
        
        // 使用缓动动画恢复
        // tween(this.node)
        //     .to(0.3, { scale: this.originalScale })
        //     .start();
        
        // 简单版本：直接恢复
        this.scheduleOnce(() => {
            this.node.scale = this.originalScale.clone();
        }, 0.1);
    }
    
    /**
     * 生成粒子效果
     */
    spawnParticle(position: Vec3) {
        if (!this.particlePrefab) {
            console.warn('请设置粒子预制体');
            return;
        }
        
        // 实例化粒子
        const particleNode = instantiate(this.particlePrefab);
        
        // 设置父节点为当前节点的父节点（这样Sprite隐藏时粒子还能显示）
        if (this.node.parent) {
            this.node.parent.addChild(particleNode);
        } else {
            particleNode.parent = this.node;
        }
        
        // 设置位置（世界坐标）
        const worldPos = this.node.getWorldPosition();
        particleNode.setWorldPosition(worldPos);
        
        // 获取粒子系统组件
        const particleSystem = particleNode.getComponent(ParticleSystem2D);
       // 获取 l 脚本组件
    const lScript = particleNode.getComponent(l) as any; // 使用组件名或类型
    if (lScript) {
        // 直接将当前节点作为颜色源节点传递
        lScript.colorSourceNode = this.node;
        // 如果 l 脚本需要立即读取纹理像素，调用其方法
        if (lScript.readTexturePixels) {
            lScript.readTexturePixels();
        }
    }
        if (particleSystem) {
            // 播放粒子效果








            particleSystem.resetSystem();
            
            // 如果需要自动销毁
            if (this.autoDestroy) {
                this.scheduleOnce(() => {
                    if (particleNode && particleNode.isValid) {
                        particleNode.destroy();
                    }
                }, this.destroyDelay);
            }
        }
        
        return particleNode;
    }
    onLoad(){
        

        if(this.node.name.includes("o")){
            this.node.setSiblingIndex(14);
        }
        const o=this.node.getSiblingIndex();
        console.log(this.node.name,"/",o);






        console.log("zha");
        
    }
}


