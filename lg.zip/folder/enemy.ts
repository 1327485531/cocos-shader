import { _decorator, CircleCollider2D, Collider2D, Component, Contact2DType, instantiate, IPhysics2DContact, Node, ParticleSystem2D, Prefab, RigidBody2D, v3, Vec2, Vec3 } from 'cc';
import { l } from './l';
import { zd } from './zd';
const { ccclass, property } = _decorator;

@ccclass('enemy')
export class enemy extends Component {
    @property(Prefab)
    lizi:Prefab=null;
    @property
    speed: number = 500;
    
    @property
    destoryDelay:number=0.7;
    private direction: Vec3 = new Vec3(0, 1, 0);

    public setDirection(dir: Vec3) {
        Vec3.normalize(this.direction, dir);
        console.log("子弹方向设置:", this.direction);
    }
    protected onLoad(): void {
        const collider = this.getComponent(Collider2D);
    if (collider) {


        collider.on(Contact2DType.BEGIN_CONTACT, this.onBeginContact, this);
        //collider.on(Contact2DType.END_CONTACT, this.onendContact, this);
    
    }
    }



    // 碰撞回调
    onBeginContact(selfCollider: Collider2D, otherCollider: Collider2D, contact: IPhysics2DContact | null) {
        
        const bullet = otherCollider.node.getComponent(zd);
    if (!bullet) return;

    // 获取子弹方向
    const bulletDir = bullet.direction;

    // 计算反方向的角度（直接用子弹方向 + 180°）
    const angle = (Math.atan2(bulletDir.y, bulletDir.x) * 180 / Math.PI ) % 360;

    // 获取碰撞点
    const worldManifold = contact.getWorldManifold();



























    const pos = new Vec3(worldManifold.points[0].x, worldManifold.points[0].y, 0);

    this.spawnParticle(pos, angle);
    this.scheduleOnce(()=>{
        this.node.destroy();
    })
}
























//spawnParticle(o: Vec3,angle:number) {
    spawnParticle(worldPos: Vec3, oppositeDir: number) {
        if (!this.lizi) {
            console.warn('请设置粒子预制体');
            return;
        }
        
        // 实例化粒子






        const particleNode = instantiate(this.lizi);
        const o=particleNode.getComponent(ParticleSystem2D);
        o.angle=oppositeDir;
        // 设置父节点为当前节点的父节点（这样Sprite隐藏时粒子还能显示）
        if (this.node.parent) {
            this.node.parent.addChild(particleNode);
        } else {
            particleNode.parent = this.node;
        }
        
        // 设置位置（世界坐标）
        
        particleNode.setWorldPosition(worldPos);
        
        // 获取粒子系统组件
        const particleSystem = particleNode.getComponent(ParticleSystem2D);
       // 获取 l 脚本组件
    const lScript = particleNode.getComponent(l) as any; // 使用组件名或类型
    if (lScript) {
        // 直接将当前节点作为颜色源节点传递
        lScript.colorSourceNode = this.node;
        // 如果 l 脚本需要立即读取纹理像素，调用其方法
        if (lScript.readTexturePixels) {
            lScript.readTexturePixels();
        }
    }
        if (particleSystem) {
            // 播放粒子效果








            particleSystem.resetSystem();
            
            






    this.scheduleOnce(() => {
        if (particleNode.isValid) particleNode.destroy();
    }, this.destoryDelay);
}
}

    fangxianglizi(contact:IPhysics2DContact){
        // 2. 获取碰撞点的法向量
    //const worldManifold = contact.getWorldManifold();
    //const normal = worldManifold.normal;

    // normal 是一个 Vec2 对象，已经标准化（长度为1）
    

    // 例如：normal = (0.707, 0.707) 表示从左下角撞过来
    
    // 3. 计算碰撞角度（以正右方为0度，逆时针为正）
    //const angleRad = Math.atan2(normal.negative().y, normal.negative().x);   // 弧度值

    // 只保留一个正确的计算
    const worldManifold = contact.getWorldManifold();
    const normal = worldManifold.normal;
    
    console.log(`法向量: (${normal.x}, ${normal.y})`);
    
    // ✅ 方案A：如果粒子0度向右，想要从敌人喷向弹珠来时的方向
    // 这个方向就是法向量的方向
    let particleAngle = Math.atan2(normal.y, normal.x) * 180 / Math.PI;
    
    console.log(`方案A角度: ${particleAngle}度`);
    
    // ✅ 如果方案A不对，试试方案B（取反）
    // let particleAngle = Math.atan2(-normal.y, -normal.x) * 180 / Math.PI;
    // console.log(`方案B角度: ${particleAngle}度`);
    
    // ✅ 如果还不对，方案C：固定加上/减去90度（根据现象调整）
    // let particleAngle = Math.atan2(normal.y, normal.x) * 180 / Math.PI + 90;
    // console.log(`方案C角度: ${particleAngle}度`);
    
    // ✅ 打印方向名称帮助调试
    const angleName = this.getAngleName(particleAngle);
    console.log(`计算出的方向: ${angleName}`);
    
    //this.showlizi(particleAngle);
    //console.log(`碰撞角度: ${angle}度`);
    //this.showlizi(particleAngle);
    return particleAngle;
    }




    


    private getAngleName(angle: number): string {
        // 标准化到0-360
        let normalizedAngle = angle % 360;
        if (normalizedAngle < 0) normalizedAngle += 360;
        
        if (normalizedAngle >= 315 || normalizedAngle < 45) return "右";
        if (normalizedAngle >= 45 && normalizedAngle < 135) return "上";
        if (normalizedAngle >= 135 && normalizedAngle < 225) return "左";
        return "下";
    }

    showlizi(position:number){
        const l = instantiate(this.lizi);
        const lizi=l.getComponent(ParticleSystem2D);
        //lizi.angle=this.getAngleToEnemy(this.node.position,this.diren.position);
    // 添加到场景根节点
    //if(this.node.parent && this.node.parent.parent){
        this.node.parent.addChild(l);
        
        // 将本地坐标转换为世界坐标
        let worldPos = v3();
        this.node.getWorldPosition(worldPos);
        l.setWorldPosition(worldPos);


        l.angle=(position+180)%360;
    //}
    

    this.scheduleOnce(() => {
        if(l.isValid) l.destroy();
    }, 7);
    

}

    start() {
      
    }

    update(deltaTime: number) {
       
    }
   
}


