import { _decorator, Collider2D, Component, Contact2DType, IPhysics2DContact, Node, Vec3 } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('zd')
export class zd extends Component {
    @property
    speed: number = 500;

    public direction: Vec3 = new Vec3(0, 1, 0);

    public setDirection(dir: Vec3) {
        Vec3.normalize(this.direction, dir);
        console.log("子弹方向设置:", this.direction);
    }



    protected onLoad(): void {
        







        const collider = this.getComponent(Collider2D);
    if (collider) {


        collider.on(Contact2DType.BEGIN_CONTACT, this.onBeginContact, this);
    }
    }
     // 碰撞回调
     onBeginContact(selfCollider: Collider2D, otherCollider: Collider2D, contact: IPhysics2DContact | null) {
        
        console.log("碰撞发生", otherCollider.node.name); // 先看是否触发
        // 如果只想处理与子弹的碰撞，可以判断节点名或标签
        if (otherCollider.node.name.includes("q")) {
            // 生成粒子
            const worldManifold = contact.getWorldManifold();
            const pos = new Vec3(worldManifold.points[0].x, worldManifold.points[0].y, 0);

            let angle=0;

            
            // 1. Sprite消失（可以添加消失动画）
            this.scheduleOnce(()=>{
                this.node.destroy();
               
            },0.1);
        }
}

    start() {
        console.log("子弹创建，位置:", this.node.worldPosition);
    }

    update(deltaTime: number) {
        // 移动
        const moveDelta = new Vec3();
        Vec3.multiplyScalar(moveDelta, this.direction, this.speed * deltaTime);
        this.node.translate(moveDelta);

        // 暂时注释掉销毁逻辑，先看子弹是否出现
        // const pos = this.node.worldPosition;
        // if (Math.abs(pos.x) > 500 || Math.abs(pos.y) > 500) {
        //     this.node.destroy();
        // }
    }
    
}


