import { _decorator, CircleCollider2D, Collider2D, Component, Contact2DType, instantiate, IPhysics2DContact, Material, Node, ParticleSystem2D, Prefab, RigidBody2D, v3 } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('plz')
export class plz extends Component {
    @property(Prefab)
    lizi:Prefab=null;
    @property(Material)
    xiangsushader:Material=null;


    @property(Prefab)


    xtt:Prefab=null;
    xt:Node=null;
    zongxueliang:number=700;
    dangqianxueliang:number=700;

    @property(Prefab)

    huoqudaoju:Prefab=null;
    onLoad(){

        // 监听碰撞事件

        

    const collider = this.getComponent(Collider2D);
    if (collider) {


        collider.on(Contact2DType.BEGIN_CONTACT, this.onBeginContact, this);
        //collider.on(Contact2DType.END_CONTACT, this.onendContact, this);
    
    }

        





    }




    // 碰撞回调
    onBeginContact(selfCollider: Collider2D, otherCollider: Collider2D, contact: IPhysics2DContact | null) {
        
        //this.pengzhuangcishu=this.pengzhuangcishu+1;
        //this.peng.string=this.pengzhuangcishu.toString();
        //this.peng.node.active=true;
        const o=otherCollider.getComponent(CircleCollider2D);
        // 1. 找到 juese 子节点
    const jueseNode = selfCollider.node.getChildByName("juese");
    if (!jueseNode) {
        console.warn("找不到 juese 子节点");
        return;
    }


    
        if(o){
            

            selfCollider.node.getComponent(RigidBody2D).gravityScale=0;
            
            // 1. 极短暂变黑（0.02秒）
            //selfCollider.node.getChildByName("juese").getComponent(Sprite).color = new Color(221, 34, 34);
    
            
            if(selfCollider.node.name.includes("疯狂小炮")||selfCollider.node.name.includes("萌萌")||selfCollider.node.name.includes("钢蛋")||selfCollider.node.name.includes("地表最强")||selfCollider.node.name.includes("都给我让开")){

                
                //this.shoujishan(selfCollider);
               
                
            }
            
            
            console.log("zhuang");
            this.fangxianglizi(contact);

            //this.xiaosanshader(selfCollider);
            
        }
    }


    fangxianglizi(contact:IPhysics2DContact){
        // 2. 获取碰撞点的法向量
    //const worldManifold = contact.getWorldManifold();
    //const normal = worldManifold.normal;

    // normal 是一个 Vec2 对象，已经标准化（长度为1）
    

    // 例如：normal = (0.707, 0.707) 表示从左下角撞过来
    
    // 3. 计算碰撞角度（以正右方为0度，逆时针为正）
    //const angleRad = Math.atan2(normal.negative().y, normal.negative().x);   // 弧度值

    // 只保留一个正确的计算
    const worldManifold = contact.getWorldManifold();
    const normal = worldManifold.normal;
    
    console.log(`法向量: (${normal.x}, ${normal.y})`);
    
    // ✅ 方案A：如果粒子0度向右，想要从敌人喷向弹珠来时的方向
    // 这个方向就是法向量的方向
    let particleAngle = Math.atan2(normal.y, normal.x) * 180 / Math.PI;
    
    console.log(`方案A角度: ${particleAngle}度`);
    
    // ✅ 如果方案A不对，试试方案B（取反）
    // let particleAngle = Math.atan2(-normal.y, -normal.x) * 180 / Math.PI;
    // console.log(`方案B角度: ${particleAngle}度`);
    
    // ✅ 如果还不对，方案C：固定加上/减去90度（根据现象调整）
    // let particleAngle = Math.atan2(normal.y, normal.x) * 180 / Math.PI + 90;
    // console.log(`方案C角度: ${particleAngle}度`);
    
    // ✅ 打印方向名称帮助调试
    const angleName = this.getAngleName(particleAngle);
    console.log(`计算出的方向: ${angleName}`);
    
    //this.showlizi(particleAngle);
    //console.log(`碰撞角度: ${angle}度`);
    this.showlizi(particleAngle);
    }




    start() {


    }

    update(deltaTime: number) {


        
    }



    private getAngleName(angle: number): string {
        // 标准化到0-360
        let normalizedAngle = angle % 360;
        if (normalizedAngle < 0) normalizedAngle += 360;
        
        if (normalizedAngle >= 315 || normalizedAngle < 45) return "右";
        if (normalizedAngle >= 45 && normalizedAngle < 135) return "上";
        if (normalizedAngle >= 135 && normalizedAngle < 225) return "左";
        return "下";
    }

    showlizi(position:number){
        const l = instantiate(this.lizi);
        const lizi=l.getComponent(ParticleSystem2D);
        //lizi.angle=this.getAngleToEnemy(this.node.position,this.diren.position);
    // 添加到场景根节点
    if(this.node.parent && this.node.parent.parent){
        this.node.addChild(l);
        
        // 将本地坐标转换为世界坐标
        let worldPos = v3();
        this.node.getWorldPosition(worldPos);
        l.setWorldPosition(worldPos);


        l.angle=(position+180)%360;
    }
    

    this.scheduleOnce(() => {
        if(l.isValid) l.destroy();
    }, 7);
    

}


}


