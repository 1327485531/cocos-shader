import { _decorator, Camera, Component, EventTouch, input, Input, instantiate, Node, Prefab, Vec3 } from 'cc';
import { zd } from './zd';
const { ccclass, property } = _decorator;

@ccclass('fs')
export class fs extends Component {
    @property({ type: Node })
    player: Node = null;

    @property({ type: Prefab })
    bulletPrefab: Prefab = null;

    start() {
        input.on(Input.EventType.TOUCH_START, this.onTouchStart, this);
    }

    onDestroy() {
        input.off(Input.EventType.TOUCH_START, this.onTouchStart, this);
    }

    private onTouchStart(event: EventTouch) {
        console.log("fashe");
    if (!this.player || !this.bulletPrefab) return;

    const touchPos = event.getLocation();
    const camera = this.node.scene.getComponentInChildren(Camera);
    if (!camera) return;

    const worldPos = camera.screenToWorld(new Vec3(touchPos.x, touchPos.y, 0));
    const playerPos = this.player.worldPosition;

    // 计算方向，并强制 z=0
    const dir = new Vec3();
    Vec3.subtract(dir, worldPos, playerPos);
    dir.z = 0;  // 关键：去除 z 分量
    if (dir.length() < 0.001) return;
    dir.normalize();

    const bulletNode = instantiate(this.bulletPrefab);
    bulletNode.setPosition(this.player.position); // 或 setWorldPosition(playerPos)
    this.node.parent.addChild(bulletNode);

    const bulletComp = bulletNode.getComponent(zd);
    if (bulletComp) {
        bulletComp.setDirection(dir);
    }
    }
    

    update(deltaTime: number) {
        
    }
}


