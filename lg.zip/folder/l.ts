import { _decorator, Color, Component, ImageAsset, Node, ParticleSystem2D, Sprite, SpriteFrame, Texture2D, UITransform } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('l')
export class l extends Component {
    @property(ParticleSystem2D)
    particle: ParticleSystem2D;

    @property(Node)
    colorSourceNode: Node = null;


    @property(ImageAsset)
    private colorSourceImage: ImageAsset = null;

    private pixelData: Uint8Array = null;
    private texWidth = 0;
    private texHeight = 0;
    private uvRect: { x: number, y: number, w: number, h: number } | null = null; // 子图矩形

    private ready = false;

    private fallbackColors: Color[] = [ /* ... */ ];



    width:number=0;
    height:number=0;
    start() {
        console.log('=== l start ===');
        (this.particle as any).custom = true;
        // 不在此处读取，等待外部调用
    }

    readTexturePixels() {
        let imageAsset: ImageAsset = null;
    this.uvRect = null;

    if (this.colorSourceNode) {
        const sprite = this.colorSourceNode.getComponent(Sprite);
        const tran=this.colorSourceNode.getComponent(UITransform);
        this.width=tran.width;
        this.height=tran.height;
        if (sprite && sprite.spriteFrame) {
            const spriteFrame = sprite.spriteFrame;
            const texture = spriteFrame.texture;
            // 使用 as Texture2D 进行类型断言
            imageAsset = this.extractImageAssetFromTexture(texture as Texture2D);
            if (imageAsset) {
                const rect = spriteFrame.rect;
                if (rect && rect.width > 0 && rect.height > 0) {
                    this.uvRect = { x: rect.x, y: rect.y, w: rect.width, h: rect.height };
                }
            } else {
                console.warn('colorSourceNode 的纹理无法提取 ImageAsset');
            }
        } else {
            console.warn('colorSourceNode 缺少 Sprite 组件或 spriteFrame');
        






















    }
        }

        // 2. 后备：直接使用 colorSourceImage
        if (!imageAsset && this.colorSourceImage) {
            imageAsset = this.colorSourceImage;
        }

        if (!imageAsset) {
            console.warn('未设置有效的颜色源，将使用后备颜色');
            this.ready = false;
            return;
        }

        const img = imageAsset.data as HTMLImageElement;
        if (!img) {
            console.warn('ImageAsset 数据无效');
            this.ready = false;
            return;
        }

        if (img.complete && img.naturalWidth > 0) {
            this.processImage(img);
        } else {
            img.onload = () => this.processImage(img);
        }
    }

    private extractImageAssetFromTexture(texture: Texture2D): ImageAsset | null {
        const props = ['_image', 'image', '_img', '_textureSource'];
        for (const prop of props) {
            const asset = (texture as any)[prop];
            if (asset instanceof ImageAsset) return asset;
        }
        if (typeof (texture as any).getImage === 'function') {
            const asset = (texture as any).getImage();
            if (asset instanceof ImageAsset) return asset;
        }
        return null;
    }

    private processImage(img: HTMLImageElement) {
        this.texWidth = img.width;
        this.texHeight = img.height;

        const canvas = document.createElement('canvas');
        canvas.width = this.texWidth;
        canvas.height = this.texHeight;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0);
        const imageData = ctx.getImageData(0, 0, this.texWidth, this.texHeight);
        this.pixelData = new Uint8Array(imageData.data);
        this.ready = true;
        console.log(`图片加载完成，尺寸：${this.texWidth}x${this.texHeight}`);
    }

    lateUpdate() {
        const ps = this.particle as any;
    const simulator = ps._simulator;
    if (!simulator) return;

    const particles = simulator.particles as any[];
    if (!particles || particles.length === 0) return;

    // 设置粒子发射区域大小（同前）
    if (this.texWidth > 0 && this.texHeight > 0) {
        if (this.uvRect) {
            this.particle.posVar.x = this.width / 2;
            this.particle.posVar.y = this.height / 2;
        } else {
            this.particle.posVar.x = this.texWidth / 2;
            this.particle.posVar.y = this.texHeight / 2;
        }
    } else {
        // console.log('使用编辑器设置的粒子大小');
    }

    // 定义绝对安全的默认颜色（纯白色）
    const DEFAULT_COLOR = { r: 255, g: 255, b: 255, a: 255 };

    for (let i = 0; i < particles.length; i++) {
        const p = particles[i];
        if (!p || p.timeToLive <= 0) continue;

        let r: number, g: number, b: number, a: number;

        if (this.ready && this.pixelData) {
            // 从图片采样颜色
            let px: number, py: number;
            if (this.uvRect) {
                const u = Math.random();
                const v = Math.random();
                px = Math.floor(this.uvRect.x + u * this.uvRect.w);
                py = Math.floor(this.uvRect.y + v * this.uvRect.h);
            } else {
                px = Math.floor(Math.random() * this.texWidth);
                py = Math.floor(Math.random() * this.texHeight);
            }
            const idx = (py * this.texWidth + px) * 4;
            r = this.pixelData[idx];
            g = this.pixelData[idx + 1];
            b = this.pixelData[idx + 2];
            a = this.pixelData[idx + 3];
        } else {
            // 使用后备颜色，但要确保数组有效
            const fallback = this.fallbackColors?.[i % this.fallbackColors.length];
            if (fallback) {
                r = fallback.r;
                g = fallback.g;
                b = fallback.b;
                a = fallback.a;
            } else {
                // 后备颜色无效时使用默认颜色
                r = DEFAULT_COLOR.r;
                g = DEFAULT_COLOR.g;
                b = DEFAULT_COLOR.b;
                a = DEFAULT_COLOR.a;
            }
        }

        // 关键：检查 p.color 是否存在再调用 set
        if (p.color) {
            p.color.set(r, g, b, a);
        } else {
            // 如果 color 不存在，可以尝试赋值一个临时颜色（但通常不会发生）
            // 或者忽略该粒子（后续系统会处理）
            console.warn('粒子 color 属性不存在，跳过颜色设置');
        }
    }

    if (simulator.renderData) {
        simulator.renderData.uvDirty = true;
        if (simulator.renderData.dataHash !== undefined) {
            simulator.renderData.dataHash = 0;
        }
    }
}
}


