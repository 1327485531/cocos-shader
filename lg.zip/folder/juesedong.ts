import { _decorator, Animation, Camera, CCFloat, Collider2D, Color, Component, Contact2DType, debug, director, EventKeyboard, Graphics, input, Input, IPhysics2DContact, KeyCode, Node, PhysicsSystem2D, RigidBody2D, screen, Sprite, UITransform, Vec2, Vec3, view } from 'cc';

const { ccclass, property } = _decorator;

@ccclass('juesedong')
export class juesedong extends Component {
    @property({ type: CCFloat })
    private moveSpeed: number = 0;

    @property({ type: Node })
    spriteNode: Node = null; // 精灵节点（包含Sprite组件）

    private isMoving: boolean = false;
    private moveDirection: Vec2 = new Vec2(0, 0);
    private targetPosition: Vec3 = new Vec3();

    // 动画状态
    private lastDirection: string = "down";
    @property({ type: Camera })
    mainCamera: Camera = null;

    @property({ type: CCFloat })
    cameraFollowSpeed: number = 5;


    
    
    
    
    

   
    @property
    Rigi:RigidBody2D=null;
    onLoad() {
        this.Rigi=this.node.getComponent(RigidBody2D);
        // 初始化位置
        Vec3.copy(this.targetPosition, this.node.position);
        
        // 监听键盘事件

        this.spriteNode=this.node;
        input.on(Input.EventType.KEY_DOWN, this.onKeyDown, this);
        input.on(Input.EventType.KEY_UP, this.onKeyUp, this);
        
        const collider = this.getComponent(Collider2D);
      
        if (collider) {
            collider.on(Contact2DType.BEGIN_CONTACT, this.onBeginContact, this);
            collider.on(Contact2DType.END_CONTACT, this.onendContact, this);
            
        }
      
    }



    onendContact(selfCollider:Collider2D,otherCollider:Collider2D,contact:IPhysics2DContact | null){

        //if(otherCollider.sensor){
            
            //if(otherCollider.node.parent.name.includes("jianzhu")){
                //selfCollider.node.getComponent(Sprite).color=new Color(246,246,246,246);
            //}
            
        //}
    }

    // 碰撞回调
    onBeginContact(selfCollider: Collider2D, otherCollider: Collider2D, contact: IPhysics2DContact | null) {
    
        console.log('碰撞发生:', otherCollider.node.name);
        console.log('sensor 状态:', otherCollider.sensor);
        console.log('碰撞器类型:', otherCollider.constructor.name);
        
        if(otherCollider.sensor){
           
            //if(otherCollider.node.parent.name.includes("jianzhu")){
                //selfCollider.node.getComponent(Sprite).color=new Color(246,246,246,116);
            //}
            
                
            
        }
        console.log(otherCollider.node.name);
        



        
    }
    
    onKeyDown(event: EventKeyboard) {
        switch (event.keyCode) {
            case KeyCode.KEY_W:
                this.moveDirection.y = 1;
                // 相机跟随
        
                break;
            case KeyCode.KEY_S:
                this.moveDirection.y = -1;
                // 相机跟随
        
                break;
            case KeyCode.KEY_A:
                this.moveDirection.x = -1;
                // 相机跟随
        
                break;
            case KeyCode.KEY_D:


                this.moveDirection.x = 1;
                // 相机跟随
        
                break;
            case KeyCode.KEY_C:
                
                break;
        }
        this.isMoving = true;
        //this.updateAnimation();
    }
    
    private cameraFollow(deltaTime: number) {
        if (!this.mainCamera) return;

        const playerPos = this.node.position;
        const cameraPos = this.mainCamera.node.position;

        // 平滑跟随
        const targetCameraPos = new Vec3(playerPos.x, playerPos.y, cameraPos.z);
        const newCameraPos = new Vec3();
        Vec3.lerp(newCameraPos, cameraPos, targetCameraPos, this.cameraFollowSpeed * deltaTime);

        this.mainCamera.node.setPosition(newCameraPos);
    }










    onKeyUp(event: EventKeyboard) {
        switch (event.keyCode) {
            case KeyCode.KEY_W:
                if (this.moveDirection.y > 0) this.moveDirection.y = 0;
                break;
            case KeyCode.KEY_S:
                if (this.moveDirection.y < 0) this.moveDirection.y = 0;
                break;
            case KeyCode.KEY_A:
                if (this.moveDirection.x < 0) this.moveDirection.x = 0;
                break;
            case KeyCode.KEY_D:
                if (this.moveDirection.x > 0) this.moveDirection.x = 0;
                break;
        }
        if(this.moveDirection.x===0&&this.moveDirection.y===0){
            this.isMoving = false;
            this.node.getComponent(RigidBody2D).linearVelocity=Vec2.ZERO;
        }
        
        //this.updateAnimation();
    }

    updateAnimation() {
        

        // 根据移动方向设置动画
        if (Math.abs(this.moveDirection.y) > Math.abs(this.moveDirection.x)) {
            this.lastDirection = this.moveDirection.y > 0 ? "up" : "down";
        } else {
            if (this.moveDirection.x !== 0) {
                this.lastDirection = this.moveDirection.x > 0 ? "right" : "left";
                // 翻转精灵实现左右转身
                this.spriteNode.scale = new Vec3(
                    this.moveDirection.x > 0 ? -1 : 1, 
                    1, 
                    
                    1
                );
            }
        }
        
        
    }

    

    update(deltaTime: number) {
        

        if (!this.Rigi) return;

    if (this.isMoving) {
        const normalizedDirection = new Vec2(this.moveDirection);
        normalizedDirection.normalize();
        const moveDelta = new Vec2(
            normalizedDirection.x * this.moveSpeed,
            normalizedDirection.y * this.moveSpeed
        );
        this.Rigi.linearVelocity = moveDelta;
        this.cameraFollow(deltaTime);
    } else {
        this.Rigi.linearVelocity = new Vec2(0, 0);
    }
        

        
    }

    onDestroy() {
        input.off(Input.EventType.KEY_DOWN, this.onKeyDown, this);
        input.off(Input.EventType.KEY_UP, this.onKeyUp, this);
    }
}


